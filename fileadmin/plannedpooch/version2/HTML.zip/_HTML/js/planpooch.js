$('.toc.item').click(function() {
  $('.ui.sidebar').sidebar('toggle');
});

$('.ui.dropdown').dropdown();

 // Input
$('.ui.radio.checkbox')
  .checkbox()
;
 

