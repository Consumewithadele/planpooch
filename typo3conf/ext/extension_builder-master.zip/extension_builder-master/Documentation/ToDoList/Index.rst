﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _todo:

To-Do list
==========

There are still many features missing. We will try to complete them step by step.

You will find them in the `bug tracker <http://forge.typo3.org/projects/extension-extension_builder/issues>`_

If you have a missing feature which you consider useful report it there.


If you are an experienced PHP developer and want to participate in a great Open Source community, consider to contribute
to the ExtensionBuilder and become a team member http://forge.typo3.org/projects/extension-extension_builder
