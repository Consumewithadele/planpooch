/**
 * WireIt.util.DD is a wrapper class for YAHOO.util.DD, to redraw the wires associated with the given terminals while drag-dropping
 * @class DD
 * @namespace WireIt.util
 * @extends YAHOO.util.DD
 * @constructor
 * @param {Array} terminals List of WireIt.Terminal objects associated within the DragDrop element
 * @param {String} id Parameter of YAHOO.util.DD
 * @param {String} sGroup Parameter of YAHOO.util.DD
 * @param {Object} config Parameter of YAHOO.util.DD
 */
WireIt.util.DD = function(terminals, id, sGroup, config) {
	if (!terminals) {
		throw new Error("WireIt.util.DD needs at least terminals and id");
	}
	/**
	 * List of the contained terminals
	 * @property _WireItTerminals
	 * @type {Array}
	 */
	this._WireItTerminals = terminals;

	WireIt.util.DD.superclass.constructor.call(this, id, sGroup, config);
};

YAHOO.extend(WireIt.util.DD, YAHOO.util.DD, {

	/**
	 * Override YAHOO.util.DD.prototype.onDrag to redraw the wires
	 * @method onDrag
	 */
	onDrag: function(e) {
		var leftPanel = YAHOO.util.Dom.getElementsByClassName('yui-layout-unit-left');
		var leftWidth = $(leftPanel[0]).getWidth() + 10;
//		Ext.select('.WireIt-Container').each(function(element) {
//			var el = Ext.get(element);
//			if (el.getX() < leftWidth) {
//				el.setX(leftWidth);
//			}
//
//			if (el.getY() < 65) {
//				el.setY(65);
//			}
//		});

		// Make sure terminalList is an array
		var terminalList = YAHOO.lang.isArray(this._WireItTerminals) ? this._WireItTerminals : (this._WireItTerminals.isWireItTerminal ? [this._WireItTerminals] : []);
		// Redraw all the wires
		for (var i = 0; i < terminalList.length; i++) {
			if (terminalList[i].wires) {
				for (var k = 0; k < terminalList[i].wires.length; k++) {
					terminalList[i].wires[k].redraw();

				}
			}
		}

	},

	/**
	 * In case you change the terminals since you created the WireIt.util.DD:
	 * @method setTerminals
	 */
	setTerminals: function(terminals) {
		this._WireItTerminals = terminals;
	}

});
